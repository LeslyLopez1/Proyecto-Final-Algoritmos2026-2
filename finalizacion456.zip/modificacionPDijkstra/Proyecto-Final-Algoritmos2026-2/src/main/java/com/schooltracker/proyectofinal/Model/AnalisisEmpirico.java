package com.schooltracker.proyectofinal.Model;

import com.schooltracker.proyectofinal.Algoritmos.CriteriosOrden;
import com.schooltracker.proyectofinal.Algoritmos.Dijkstra;
import com.schooltracker.proyectofinal.Algoritmos.QuickSort;
import com.schooltracker.proyectofinal.Algoritmos.ShellSort;
import com.schooltracker.proyectofinal.Model.Archivos.Lector;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
 //esta clase modela el punto 6 donde hace las mediciones y comparaciones
public class AnalisisEmpirico {

    public static final String[] ARCHIVOS = {
            "grafo_peque.csv",
            "grafo_mediano.csv",
            "grafo_grande.csv"
    };

    //texto gráfica para cada archivo
    public static final String[] ETIQUETAS = {"20 vértices", "100 vértices", "500 vértices"};

    public static final String[] OPERACIONES = {
            "Importación CSV", "Construcción", "Dijkstra", "QuickSort", "Shell Sort"
    };

    private static final int REPETICIONES = 5;

    //regresa el tiempo en milisegundos
    public static double[][] ejecutar() throws IOException {
        double[][] tiempos = new double[ARCHIVOS.length][OPERACIONES.length];

        for (int i = 0; i < ARCHIVOS.length; i++) {
            final String ruta = "/CSV/analisis/" + ARCHIVOS[i];
            final Lector lector = new Lector();

            // El grafo se lee una vez para tener con qué probar las demás operaciones
            final Grafo grafo = lector.leerDesdeRecurso(ruta, true);
            final List<Vertice> vertices = grafo.getVertices();
            Vertice masConectado = vertices.get(0);
            for (Vertice v : vertices) {
                if (grafo.getAdyacentes(v.getId()).size() > grafo.getAdyacentes(masConectado.getId()).size()) {
                    masConectado = v;
                }
            }
            final int origenId = masConectado.getId();
            final int destinoId = vertices.get(vertices.size() - 1).getId();
            final List<Arista> aristas = grafo.getTodasLasAristas();

            tiempos[i][0] = medir(() -> {
                try {
                    lector.leerDesdeRecurso(ruta, true);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });

            tiempos[i][1] = medir(() -> {
                Grafo copia = new Grafo(true);
                for (Vertice v : vertices) {
                    copia.agregarVertice(new Vertice(v.getId(), v.getEtiqueta()));
                }
                for (Arista a : aristas) {
                    copia.agregarArista(a.getOrigen().getId(), a.getDestino().getId(), a.getPeso());
                }
            });

            tiempos[i][2] = medir(() -> Dijkstra.calcular(grafo, origenId, destinoId));

            tiempos[i][3] = medir(() -> {
                List<Arista> copia = new ArrayList<>(aristas);
                QuickSort.ordenar(copia, CriteriosOrden.POR_PESO);
            });

            tiempos[i][4] = medir(() -> {
                List<Arista> copia = new ArrayList<>(aristas);
                ShellSort.ordenar(copia, CriteriosOrden.POR_PESO);
            });
        }
        return tiempos;
    }

    private static double medir(Runnable tarea) {
        tarea.run();
        long inicio = System.nanoTime();
        for (int i = 0; i < REPETICIONES; i++) {
            tarea.run();
        }
        long fin = System.nanoTime();
        return (fin - inicio) / 1000000.0 / REPETICIONES;
    }
}
