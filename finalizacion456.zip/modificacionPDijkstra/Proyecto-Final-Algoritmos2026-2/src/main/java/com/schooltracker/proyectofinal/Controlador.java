package com.schooltracker.proyectofinal;

import com.schooltracker.proyectofinal.Algoritmos.CriteriosOrden;
import com.schooltracker.proyectofinal.Algoritmos.Dijkstra;
import com.schooltracker.proyectofinal.Algoritmos.QuickSort;
import com.schooltracker.proyectofinal.Algoritmos.Resultado;
import com.schooltracker.proyectofinal.Algoritmos.ShellSort;
import com.schooltracker.proyectofinal.Model.Arista;
import com.schooltracker.proyectofinal.Model.Grafo;
import com.schooltracker.proyectofinal.Model.MainModel;
import com.schooltracker.proyectofinal.Model.Vertice;
import com.schooltracker.proyectofinal.View.GrafoView;
import com.schooltracker.proyectofinal.View.MainView;
import com.schooltracker.proyectofinal.View.VentanaOrden;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Controlador {

    private final MainModel model;
    private final MainView view;

    public Controlador(MainModel model, MainView view) {
        if (model == null) {
            throw new IllegalArgumentException("MainModel no puede ser nulo.");
        }
        if (view == null) {
            throw new IllegalArgumentException("MainView no puede ser nula.");
        }
        this.model = model;
        this.view = view;
        configurarEventos();
    }

    private void configurarEventos() {
        view.getNavBar().onTipoGrafoChange((obs, oldVal, esDirigido) -> {
            model.setDirigido(esDirigido);
            refrescarVistaGrafo();
        });
        view.getNavBar().onVistaChange((obs, oldVal, esVistaGrafo) -> {
            if (esVistaGrafo) {
                view.mostrarGrafo();
            } else {
                view.mostrarAnalisis();
            }
        });
        //ruta optima con Dijkstra
        view.getSideBar().setOnCalcularDijkstra(e -> calcularDijkstra());
        //ordenamiento de las conexiones
        view.getSideBar().setOnQuickSort(e -> ordenarConexiones(true));
        view.getSideBar().setOnShellSort(e -> ordenarConexiones(false));
    }

    //lee origen/destino y muestra el resultado de Dijkstra
    private void calcularDijkstra() {
        Integer origenId = view.getSideBar().getOrigenDijkstraSeleccionado();
        Integer destinoId = view.getSideBar().getDestinoDijkstraSeleccionado();
        if (origenId == null || destinoId == null) {
            view.getSideBar().mostrarMensaje("Selecciona el origen y el destino.");
            return;
        }

        try {
            Resultado resultado = Dijkstra.calcular(model.getGrafoActual(), origenId, destinoId);
            String origen = resultado.getOrigen().getEtiqueta();
            String destino = resultado.getDestino().getEtiqueta();

            if (!resultado.isEncontrada()) {
                view.getSideBar().mostrarResultadoDijkstra("Origen: " + origen + "\nDestino: " + destino
                        + "\nNo existe una ruta entre ambos vértices.");
            } else {
                StringBuilder ruta = new StringBuilder();
                for (int i = 0; i < resultado.getCamino().size(); i++) {
                    if (i > 0) {
                        ruta.append(" -> ");
                    }
                    ruta.append(resultado.getCamino().get(i).getEtiqueta());
                }
                view.getSideBar().mostrarResultadoDijkstra("Origen: " + origen + "\nDestino: " + destino
                        + "\nRuta: " + ruta + "\nCosto total: " + resultado.getCosto());
            }
            view.getSideBar().mostrarMensaje("");
        } catch (IllegalArgumentException ex) {
            view.getSideBar().mostrarMensaje(ex.getMessage());
        }
    }

    //ordena con QuickSort o Shell
    private void ordenarConexiones(boolean usarQuickSort) {
        String criterio = view.getSideBar().getCriterioOrdenSeleccionado();
        if (criterio == null) {
            view.getSideBar().mostrarMensaje("Selecciona el criterio de ordenamiento.");
            return;
        }

        boolean porPeso = criterio.startsWith("Peso");
        Comparator<Arista> comparador = porPeso ? CriteriosOrden.POR_PESO : CriteriosOrden.POR_NOMBRE;
        String algoritmo = usarQuickSort ? "QuickSort" : "Shell Sort";

        List<Arista> lista = new ArrayList<>(model.getGrafoActual().getTodasLasAristas());
        if (lista.isEmpty()) {
            view.getSideBar().mostrarMensaje("El grafo no tiene conexiones para ordenar.");
            return;
        }

        long inicio = System.nanoTime();
        try {
            if (usarQuickSort) {
                QuickSort.ordenar(lista, comparador);
            } else {
                ShellSort.ordenar(lista, comparador);
            }
        } catch (StackOverflowError ex) {
            view.getSideBar().mostrarMensaje("QuickSort se desbordó con esta lista; prueba con Shell Sort.");
            return;
        }
        double milisegundos = (System.nanoTime() - inicio) / 1000000.0;

        List<String> lineas = new ArrayList<>();
        for (Arista a : lista) {
            lineas.add(a.getOrigen().getEtiqueta() + " -> " + a.getDestino().getEtiqueta() + " (" + a.getPeso() + ")");
        }

        String criterioTexto = porPeso ? "peso" : "nombre";
        view.getSideBar().mostrarResultadoOrdenamiento(algoritmo + " por " + criterioTexto + ":\n"
                + lista.size() + " conexiones en " + String.format("%.3f", milisegundos) + " ms");
        view.getSideBar().mostrarMensaje("");
        VentanaOrden.mostrar(algoritmo + " - conexiones ordenadas por " + criterioTexto, lineas);
    }

    public void refrescarVistaGrafo() {
        Grafo grafo = model.getGrafoActual();
        actualizarCombosVertices(grafo);
        if (grafo == null) {
            view.actualizarGrafoView(new GrafoView(view.getNavBar().isGrafoDirigido()));
            return;
        }

        boolean dirigido = view.getNavBar().isGrafoDirigido();
        List<String> etiquetasVertices = new ArrayList<>();
        for (Vertice v : grafo.getVertices()) {
            etiquetasVertices.add(v.getEtiqueta());
        }

        List<String> conexiones = new ArrayList<>();
        for (Arista a : grafo.getTodasLasAristas()) {
            conexiones.add(
                    a.getOrigen().getEtiqueta()
                            + " -> "
                            + a.getDestino().getEtiqueta()
                            + " ("
                            + a.getPeso()
                            + ")"
            );
        }

        GrafoView nuevaVista = new GrafoView(dirigido);
        nuevaVista.establecerDatos(etiquetasVertices, conexiones);
        view.actualizarGrafoView(nuevaVista);
    }

    private void actualizarCombosVertices(Grafo grafo) {
        Map<Integer, String> etiquetas = new LinkedHashMap<>();
        if (grafo != null) {
            for (Vertice v : grafo.getVertices()) {
                etiquetas.put(v.getId(), v.getEtiqueta());
            }
        }
        view.getSideBar().setVerticesDisponibles(etiquetas);
    }

    public MainModel getModel() {
        return model;
    }

    public MainView getView() {
        return view;
    }
}